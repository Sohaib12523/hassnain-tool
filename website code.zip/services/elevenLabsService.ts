


import type { ElevenLabsVoice, Voice } from '../types';

const API_BASE_URL = 'https://api.elevenlabs.io/v1';

/**
 * Fetches the list of available voices from the ElevenLabs API.
 * @param apiKey The user's ElevenLabs API key.
 * @returns A promise that resolves to an array of voice objects.
 */
export async function fetchVoices(apiKey: string): Promise<Voice[]> {
    if (!apiKey) {
        throw new Error("ElevenLabs API key is not provided.");
    }
    
    const response = await fetch(`${API_BASE_URL}/voices`, {
        headers: {
            'xi-api-key': apiKey,
        },
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData?.detail?.message || `Failed to fetch voices with status ${response.status}`;
        throw new Error(errorMessage);
    }

    const data = await response.json();
    const elevenVoices = data.voices as ElevenLabsVoice[];
    
    return elevenVoices.map(v => ({
        id: v.voice_id,
        name: v.name,
        provider: 'elevenlabs',
        group: v.category
    }));
}

/**
 * Generates audio from text using the ElevenLabs text-to-speech API.
 * @param apiKey The user's ElevenLabs API key.
 * @param voiceId The ID of the voice to use for generation.
 * @param text The text to convert to speech.
 * @param speed A percentage from 0 (slowest) to 100 (fastest). 50 is default speed.
 * @returns A promise that resolves to an audio Blob.
 */
export async function generateAudio(apiKey: string, voiceId: string, text: string, speed: number): Promise<Blob> {
     if (!apiKey) {
        throw new Error("ElevenLabs API key is not provided.");
    }
     if (!voiceId) {
        throw new Error("Voice ID is not provided.");
    }
     if (!text || !text.trim()) {
        // Return a silent blob if there's no text to avoid errors
        return new Blob([], { type: 'audio/mpeg' });
    }

    let ssmlText: string;
    const containsSSML = text.includes('<') && text.includes('>');

    if (containsSSML) {
        // Text already contains SSML, just wrap it in <speak> tags.
        // The user-provided SSML will override the basic speed setting.
        ssmlText = `<speak>${text}</speak>`;
    } else {
        // No SSML detected, build it from scratch with speed control.
        // Convert speed (0-100) to a prosody rate percentage (e.g., 50 -> 100%, 0 -> 50%, 100 -> 150%)
        const rate = Math.round(50 + speed); 
        const escapedText = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
        ssmlText = `<speak><prosody rate="${rate}%">${escapedText}</prosody></speak>`;
    }


    const response = await fetch(`${API_BASE_URL}/text-to-speech/${voiceId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg',
            'xi-api-key': apiKey,
        },
        body: JSON.stringify({
            text: ssmlText,
            // Use an SSML-compatible model. 'eleven_multilingual_v1' is faster than v2 for better performance.
            // The 'eleven_turbo_v2' model is faster but would ignore SSML tags (like speed adjustments).
            model_id: 'eleven_multilingual_v1',
            voice_settings: {
                stability: 0.5,
                similarity_boost: 0.75,
                use_speaker_boost: true
            },
        }),
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData?.detail?.message || `Failed to generate audio with status ${response.status}`;
        throw new Error(errorMessage);
    }

    return response.blob();
}

/**
 * Generates a sound effect from a text prompt using the ElevenLabs API.
 * @param apiKey The user's ElevenLabs API key.
 * @param text The description of the sound effect.
 * @param duration_seconds The desired duration of the sound effect (3-22s).
 * @returns A promise that resolves to an audio Blob.
 */
export async function generateSoundEffect(apiKey: string, text: string, duration_seconds: number): Promise<Blob> {
    if (!apiKey) {
        throw new Error("ElevenLabs API key is not provided.");
    }
    if (!text.trim()) {
        return new Blob([], { type: 'audio/mpeg' });
    }

    // Clamp duration to be within the API's allowed range (3 to 22 seconds)
    const clampedDuration = Math.max(3, Math.min(22, duration_seconds));

    const response = await fetch(`${API_BASE_URL}/sound-generation`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg',
            'xi-api-key': apiKey,
        },
        body: JSON.stringify({
            text: text,
            duration_seconds: clampedDuration,
        }),
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData?.detail?.message || errorData?.detail || `Failed to generate sound effect with status ${response.status}`;
        throw new Error(errorMessage);
    }

    return response.blob();
}


import type { GenerationParams, GenerationResult, BulkScriptApiProvider } from '../types';
import type { AspectRatio } from '../types';

const defaultApiKey = process.env.API_KEY;

const TOGETHER_SUPPORTED_STYLES = ['None', 'Cinematic', 'Photographic', 'Anime', 'Digital Art', 'Fantasy', 'Low Poly', 'Pixel Art', 'Comic Book', 'Abstract'];

export async function getStyles(apiKey?: string | null): Promise<string[]> {
    return Promise.resolve(TOGETHER_SUPPORTED_STYLES);
}

const sizeMap: Record<AspectRatio, { width: number, height: number }> = {
  "1:1": { width: 1024, height: 1024 },
  "16:9": { width: 1280, height: 720 },
  "9:16": { width: 720, height: 1280 },
  "4:3": { width: 1024, height: 768 },
  "3:4": { width: 768, height: 1024 }
};

/**
 * A wrapper function to retry API calls with exponential backoff.
 * @param apiCall The async function to call.
 * @param maxRetries Maximum number of retries.
 * @param initialDelayMs Initial delay in milliseconds.
 * @param maxDelayMs Maximum delay in milliseconds.
 * @returns The result of the API call.
 */
async function withRetry<T>(
    apiCall: () => Promise<T>,
    maxRetries: number = 3,
    initialDelayMs: number = 2000,
    maxDelayMs: number = 30000
): Promise<T> {
    let attempt = 0;
    while (true) {
        try {
            return await apiCall();
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message.toLowerCase() : '';
            // Check for common rate limit or server overload error messages/codes
            const isRateLimitError = errorMessage.includes('429') || errorMessage.includes('rate limit') || errorMessage.includes('rate_limit_exceeded') || errorMessage.includes('503');

            if (isRateLimitError && attempt < maxRetries) {
                attempt++;
                const delay = Math.min(initialDelayMs * Math.pow(2, attempt - 1), maxDelayMs);
                // Add some jitter to avoid thundering herd
                const jitter = delay * 0.2 * Math.random();
                console.warn(`Retriable error detected. Retrying attempt ${attempt}/${maxRetries} in ${Math.round(delay + jitter)}ms...`);
                await new Promise(resolve => setTimeout(resolve, delay + jitter));
            } else {
                // Non-retriable error or max retries reached
                throw error;
            }
        }
    }
}


export async function generateSingleImage(prompt: string, ratio: AspectRatio, steps: number, apiKey?: string | null): Promise<GenerationResult> {
    const activeApiKey = apiKey || defaultApiKey;
    const { width, height } = sizeMap[ratio] || sizeMap["1:1"];
    
    try {
        if (!activeApiKey) {
          throw new Error("API key is not configured.");
        }

        const response = await withRetry(async () => {
            const res = await fetch("https://api.together.xyz/v1/images/generations", {
                method: "POST",
                headers: {
                    Authorization: `Bearer ${activeApiKey}`,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    model: "black-forest-labs/FLUX.1-schnell-Free",
                    prompt,
                    width,
                    height,
                    steps,
                    n: 1,
                    response_format: "b64_json",
                }),
            });

            if (!res.ok) {
                const errorData = await res.json().catch(() => ({}));
                const errorMessage = errorData?.error?.message || errorData?.message || `Request failed with status ${res.status}`;
                // Throw an error, which will be caught by withRetry.
                // If it's a rate limit error, withRetry will handle the delay and retry.
                // Otherwise, it will re-throw the error after max retries.
                throw new Error(errorMessage);
            }
            return res;
        });

        const data = await response.json();
        const base64Json = data?.data?.[0]?.b64_json;
        if (base64Json) {
            return { prompt, url: `data:image/png;base64,${base64Json}` };
        } else {
            throw new Error("Image data (b64_json) not found in API response.");
        }
    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred';
        return { prompt, url: undefined, error: errorMessage };
    }
}

export async function generateImages({ prompts, ratio, steps = 10, onProgress, apiKey }: GenerationParams): Promise<void> {
    // Process prompts sequentially to manage the TogetherAI rate limit (6/min).
    // A 10-second delay between each request ensures the tool stays within this limit.
    for (let i = 0; i < prompts.length; i++) {
        const prompt = prompts[i];
        
        // Generate a single image and report progress. The `withRetry` logic is inside `generateSingleImage`.
        const result = await generateSingleImage(prompt, ratio, steps, apiKey);
        onProgress(i, result);

        // If this is not the last prompt in the list, wait for 10 seconds before making the next call.
        if (i < prompts.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 10000));
        }
    }
}

// --- Text Generation for Bulk Scripts ---

const PROVIDER_CONFIG: Record<Exclude<BulkScriptApiProvider, 'gemini'>, { baseURL: string, defaultModel: string }> = {
    openai: {
        baseURL: "https://api.openai.com/v1/chat/completions",
        defaultModel: "gpt-4-turbo-preview",
    },
    groq: {
        baseURL: "https://api.groq.com/openai/v1/chat/completions",
        defaultModel: "llama3-8b-8192",
    },
    deepseek: {
        baseURL: "https://api.deepseek.com/v1/chat/completions",
        defaultModel: "deepseek-chat",
    }
};

export async function fetchModelsForProvider(provider: Exclude<BulkScriptApiProvider, 'gemini'>, apiKey: string): Promise<string[]> {
    const URLS: Record<Exclude<BulkScriptApiProvider, 'gemini'>, string> = {
        openai: "https://api.openai.com/v1/models",
        groq: "https://api.groq.com/openai/v1/models",
        deepseek: "https://api.deepseek.com/v1/models",
    };

    const url = URLS[provider];
    if (!url) throw new Error(`Unsupported provider for model fetching: ${provider}`);

    try {
        const response = await fetch(url, {
            method: "GET",
            headers: {
                Authorization: `Bearer ${apiKey}`,
            },
        });

        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData?.error?.message || `Failed to fetch models: ${response.statusText}`);
        }

        const data = await response.json();
        const modelList = data.data || data;
        
        if (!Array.isArray(modelList)) throw new Error("Unexpected API response format for models.");

        return modelList
            .map((model: any) => model.id)
            .filter((id: string) => {
                if (!id) return false;
                if (provider === 'groq') {
                    // Groq offers Llama, Mixtral, and Gemma models for chat
                    return id.includes('llama') || id.includes('mixtral') || id.includes('gemma');
                }
                return true; // No specific filter for other providers
            })
            .sort();

    } catch (error) {
        console.error(`Error fetching models for ${provider}:`, error);
        throw error;
    }
}


async function generateChatCompletion(systemPrompt: string, userPrompt: string, apiKey: string, provider: Exclude<BulkScriptApiProvider, 'gemini'>, model: string, useJson: boolean = false) {
    const config = PROVIDER_CONFIG[provider];
    if (!config) throw new Error(`Unsupported provider: ${provider}`);

    const body: any = {
        model: model || config.defaultModel,
        messages: [
            { role: "system", content: systemPrompt },
            { role: "user", content: userPrompt }
        ]
    };

    if (useJson) {
        body.response_format = { type: "json_object" };
    }

    const response = await fetch(config.baseURL, {
        method: "POST",
        headers: {
            Authorization: `Bearer ${apiKey}`,
            "Content-Type": "application/json",
        },
        body: JSON.stringify(body),
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData?.error?.message || `Request failed with status ${response.status}`;
        throw new Error(errorMessage);
    }

    const data = await response.json();
    const content = data?.choices?.[0]?.message?.content;
    if (!content) {
        throw new Error("Content not found in API response.");
    }
    return content;
}

export async function generateOutlineForTitle(title: string, wordCount: number, apiKey: string, provider: Exclude<BulkScriptApiProvider, 'gemini'>, model: string): Promise<{ guides: string; outline: string; }> {
    if (!apiKey) throw new Error("API Key is required for this provider.");

    const systemPrompt = `You are an expert content strategist and professional script planner. Your task is to analyze a video title and a target word count, then create a professional, comprehensive plan for writing the script.
Your output MUST be a valid JSON object with two keys: "guides" and "outline".
1.  **guides**: This should be a string containing a bulleted list of essential writing guidelines. It must cover the recommended tone, style, target audience, and key points to include or avoid. The advice should be actionable and professional.
2.  **outline**: This should be a string containing a detailed, professionally structured outline for the script.
    -   Use Markdown for formatting: Use \`**double asterisks**\` to make headings and key terms bold for emphasis and clarity.
    -   The structure should be logical, typically including an Introduction (with a strong hook), a Main Body (broken into several distinct, well-defined points), and a Conclusion (with a summary and a call to action or final thought).
    -   The detail should be sufficient to guide the writing of a script of approximately ${wordCount} words.`;
    
    const userPrompt = `USER INPUT:\nTitle: "${title}"\nWord Count: ${wordCount}`;
    
    const jsonString = await generateChatCompletion(systemPrompt, userPrompt, apiKey, provider, model, true);
    const result = JSON.parse(jsonString);

    if (!result || typeof result.guides !== 'string' || typeof result.outline !== 'string') {
        throw new Error("API returned an unexpected format for outline generation.");
    }

    return result;
}

export async function generateSingleScript(title: string, guides: string, outline: string, wordCount: number, apiKey: string, provider: Exclude<BulkScriptApiProvider, 'gemini'>, model: string): Promise<string> {
    if (!apiKey) throw new Error("API Key is required for this provider.");
    
    const wordCountInstruction = wordCount > 0
        ? `**4. Word Count:** The final script should be approximately **${wordCount} words** long.`
        : `**4. Word Count:** The desired word count is not explicitly set. You MUST INFER the target length from the details and scope provided in the **Writing Guidelines** and **Script Outline**.`;
    
    const systemPrompt = `You are a world-class, expert scriptwriter. Your task is to write a high-quality, professional script based on the provided title, detailed guidelines, and a specific structural outline. You must adhere to all instructions precisely.

**1. Script Title:** The central theme of the script is:
<title>
${title}
</title>

**2. Writing Guidelines (MUST FOLLOW):** You must adhere strictly to these guidelines for the tone, style, voice, and content:
<guidelines>
${guides}
</guidelines>

**3. Script Outline (MUST FOLLOW):** The script must follow this exact structure. Flesh out each section thoughtfully and creatively based on the outline provided. Do not deviate from this structure.
<outline>
${outline}
</outline>

${wordCountInstruction}

**CRITICAL Final Instructions:**
- The final output must be **pure, ready-to-use prose or narrative text only**.
- **DO NOT** include any script-formatting words, tags, or labels like "NARRATOR:", "SCENE 1:", "INTRO:", "[SCENE START]", "INT./EXT.", or any other directorial notes. The text should be immediately readable by a voice-over artist without any cleanup.
- Ensure the final text flows naturally as a single, cohesive piece.
- Adhere as closely as possible to the word count requirement if one is specified.
- Do not add any of your own comments, introductions, or text outside of the requested script itself.`;
    
    const userPrompt = "Please generate the script now based on the detailed instructions provided in the system prompt.";

    const script = await generateChatCompletion(systemPrompt, userPrompt, apiKey, provider, model);
    return script;
}
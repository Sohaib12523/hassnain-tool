





import { GoogleGenAI, Type, GenerateImagesResponse, GenerateContentResponse } from "@google/genai";
import type { GenerationParams, GenerationResult, AspectRatio } from '../types';

const defaultAi = process.env.API_KEY ? new GoogleGenAI({ apiKey: process.env.API_KEY }) : undefined;

// This constant is now the source of truth for Gemini/default styles.
const GEMINI_SUPPORTED_STYLES = ['None', 'Cinematic', 'Photographic', 'Anime', 'Digital Art', 'Fantasy', 'Low Poly', 'Pixel Art', 'Comic Book', 'Abstract'];


/**
 * Returns the list of styles supported by the default services.
 */
export async function getStyles(apiKey?: string | null): Promise<string[]> {
    // Gemini styles are currently static and don't depend on the key.
    return Promise.resolve(GEMINI_SUPPORTED_STYLES);
}


/**
 * A wrapper function to retry API calls with exponential backoff.
 * @param apiCall The async function to call.
 * @param maxRetries Maximum number of retries.
 * @param initialDelayMs Initial delay in milliseconds.
 * @param maxDelayMs Maximum delay in milliseconds.
 * @returns The result of the API call.
 */
async function withRetry<T>(
    apiCall: () => Promise<T>,
    maxRetries: number = 3,
    initialDelayMs: number = 1000,
    maxDelayMs: number = 16000
): Promise<T> {
    let attempt = 0;
    while (true) {
        try {
            return await apiCall();
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message.toLowerCase() : '';
            const isRateLimitError = errorMessage.includes('429') || errorMessage.includes('rate limit') || errorMessage.includes('resource_exhausted');

            if (isRateLimitError && attempt < maxRetries) {
                attempt++;
                const delay = Math.min(initialDelayMs * Math.pow(2, attempt - 1), maxDelayMs);
                // Add some jitter to avoid thundering herd
                const jitter = delay * 0.2 * Math.random();
                console.warn(`Rate limit hit. Retrying attempt ${attempt}/${maxRetries} in ${Math.round(delay + jitter)}ms...`);
                await new Promise(resolve => setTimeout(resolve, delay + jitter));
            } else {
                // Non-retriable error or max retries reached
                throw error;
            }
        }
    }
}


export async function generateSingleImage(prompt: string, ratio: AspectRatio, apiKey?: string | null): Promise<GenerationResult> {
    const client = apiKey ? new GoogleGenAI({ apiKey }) : defaultAi;
    
    if (!client) {
        return { prompt, url: undefined, error: "Image generation API key is not configured or is invalid." };
    }
    try {
        const response: GenerateImagesResponse = await withRetry(() => client!.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: prompt,
            config: {
                numberOfImages: 1,
                aspectRatio: ratio,
                outputMimeType: 'image/png',
            },
        }));

        const generatedImage = response.generatedImages[0];
        const base64ImageBytes = generatedImage?.image?.imageBytes;

        if (base64ImageBytes) {
            return { prompt, url: `data:image/png;base64,${base64ImageBytes}` };
        } else {
            throw new Error("Image data not found in Gemini API response. The generation may have been blocked or failed.");
        }
    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'An unknown error occurred during Gemini image generation';
        console.error(error);
        return { prompt, url: undefined, error: errorMessage };
    }
}

export async function generateImages({ prompts, ratio, onProgress, apiKey }: GenerationParams): Promise<void> {
    const CONCURRENCY_LIMIT = 5; 

    for (let i = 0; i < prompts.length; i += CONCURRENCY_LIMIT) {
        const batch = prompts.slice(i, i + CONCURRENCY_LIMIT);
        const promises = batch.map((prompt, index) => {
            const originalIndex = i + index;
            return generateSingleImage(prompt, ratio, apiKey).then(result => {
                onProgress(originalIndex, result);
            });
        });
        await Promise.all(promises);
    }
}

export async function extractCharactersFromScript(script: string): Promise<{ characters: string[]; mainCharacter: string | null; }> {
    if (!defaultAi) {
        throw new Error("API key is not configured for text generation.");
    }
    try {
        const systemPrompt = `Analyze the following script. Identify all unique character names and determine who is the main character of the story. The main character is the one the story is centered around. Return the result as a JSON object with two keys: "characters" (a list of all unique character names) and "mainCharacter" (the name of the single most important character, which must be one of the names from the 'characters' list). If no clear main character can be identified, the value for "mainCharacter" should be null. The output must be a valid JSON object. For example: {"characters": ["JOHN", "MARY", "VILLAIN"], "mainCharacter": "JOHN"}`;

        const response: GenerateContentResponse = await withRetry(() => defaultAi!.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `${systemPrompt}\n\nSCRIPT:\n---\n${script}\n---`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        characters: {
                            type: Type.ARRAY,
                            description: "A list of all unique character names found in the script.",
                            items: {
                                type: Type.STRING,
                                description: "A character's name."
                            }
                        },
                        mainCharacter: {
                            type: Type.STRING,
                            description: "The name of the main character. Null if not identifiable."
                        }
                    },
                    required: ["characters", "mainCharacter"]
                }
            }
        }));

        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText) as { characters: unknown; mainCharacter: unknown };

        if (!result || typeof result !== 'object' || !Array.isArray(result.characters) || !result.characters.every(c => typeof c === 'string')) {
            throw new Error("API returned an unexpected format for characters list.");
        }
        if (!('mainCharacter' in result) || (result.mainCharacter !== null && typeof result.mainCharacter !== 'string')) {
             throw new Error("API returned an unexpected format for main character.");
        }
        
        const characters = result.characters.map((c: string) => c.toUpperCase());
        const mainCharacter = typeof result.mainCharacter === 'string' ? result.mainCharacter.toUpperCase() : null;
        
        return { characters, mainCharacter };

    } catch (error) {
        console.error("Error extracting characters from script:", error);
        const errorMessage = error instanceof Error ? `Character extraction failed: ${error.message}` : 'An unknown error occurred during character extraction';
        throw new Error(errorMessage);
    }
}

export async function describeImage(base64Image: string): Promise<string> {
    if (!defaultAi) {
        throw new Error("API key is not configured for image analysis.");
    }
    try {
        const imagePart = {
            inlineData: {
                mimeType: 'image/jpeg', // This is a safe default
                data: base64Image
            }
        };
        
        const textPart = {
            text: "Analyze the person in this image and create a detailed, specific description suitable for a text-to-image AI model. Focus on immutable features to ensure character consistency. Describe their facial structure, eye color, hair style and color, ethnicity, approximate age, body type, and any permanent features like scars or tattoos. Then, describe their clothing. The description should be a concise paragraph."
        };

        const response: GenerateContentResponse = await withRetry(() => defaultAi!.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] }
        }));

        return response.text;

    } catch (error) {
        console.error("Error describing image:", error);
        const errorMessage = error instanceof Error ? `Image description failed: ${error.message}` : 'An unknown error occurred during image description';
        throw new Error(errorMessage);
    }
}

export async function describeImageStyle(base64Image: string): Promise<string> {
    if (!defaultAi) {
        throw new Error("API key is not configured for image analysis.");
    }
    try {
        const imagePart = {
            inlineData: {
                mimeType: 'image/jpeg', // A safe default
                data: base64Image
            }
        };
        
        const textPart = {
            text: "Analyze the artistic style of this image. Describe the style in a short, concise phrase suitable for a text-to-image AI prompt. Focus ONLY on the stylistic elements like mood, lighting, color palette, texture, rendering style (e.g., photographic, painting, anime), and overall artistic direction. DO NOT describe the subject matter of the image. For example: 'cinematic, high contrast, dramatic lighting' or 'soft, pastel, watercolor illustration' or 'vintage comic book art, faded colors, ink outlines'."
        };

        const response: GenerateContentResponse = await withRetry(() => defaultAi!.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [imagePart, textPart] }
        }));

        return response.text.trim();

    } catch (error) {
        console.error("Error describing image style:", error);
        const errorMessage = error instanceof Error ? `Style analysis failed: ${error.message}` : 'An unknown error occurred during style analysis';
        throw new Error(errorMessage);
    }
}

export async function generateScenesFromScript(script: string, numScenes: number, characterDetails: Record<string, { description: string }>): Promise<string[]> {
    if (!defaultAi) {
        throw new Error("API key is not configured for text generation.");
    }
    try {
        const hasCharacterDetails = Object.keys(characterDetails).length > 0;
        
        let characterInstruction = "Describe any characters in the scenes vividly.";

        if (hasCharacterDetails) {
            characterInstruction = `CRITICAL INSTRUCTION: You MUST use the following character descriptions to ensure consistency. For any scene containing one of these characters (e.g., "JOHN" or "MARY'S FRIEND"), you MUST incorporate their corresponding description into the image prompt.

CHARACTER DESCRIPTIONS:
${JSON.stringify(characterDetails, null, 2)}
            `;
        }

        const systemPrompt = `You are an expert film director creating a storyboard. Your task is to analyze the following script and break it down into ${numScenes} distinct visual scenes. For each scene, create a detailed and descriptive image generation prompt that captures the key characters, setting, action, and mood. The prompt must be suitable for a text-to-image AI model.
${characterInstruction}`;

        const response: GenerateContentResponse = await withRetry(() => defaultAi!.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `${systemPrompt}

Here is the script:
---
${script}
---`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    description: `A list of ${numScenes} image generation prompts, one for each scene.`,
                    items: {
                        type: Type.STRING,
                        description: 'A detailed, descriptive prompt for an AI image generator, capturing the visual essence of a scene.'
                    }
                }
            }
        }));

        const jsonText = response.text.trim();
        const prompts = JSON.parse(jsonText);

        if (!Array.isArray(prompts) || !prompts.every(p => typeof p === 'string')) {
            throw new Error("API returned an unexpected format. Expected an array of strings.");
        }

        return prompts;

    } catch (error) {
        console.error("Error generating scenes from script:", error);
        const errorMessage = error instanceof Error ? `Scene generation failed: ${error.message}` : 'An unknown error occurred during scene generation';
        throw new Error(errorMessage);
    }
}

export async function generateScriptFromIdea(idea: string, durationInMinutes: number): Promise<string> {
    if (!defaultAi) {
        throw new Error("API key is not configured for text generation.");
    }
    try {
        const systemPrompt = `You are a creative screenwriter. Based on the following user idea, write a short, visual script suitable for a video that is approximately ${durationInMinutes} minute(s) long. The script should focus on clear, concise visual descriptions and dialogue, suitable for generating image prompts later. Do not include camera directions like 'CLOSE UP' or 'PAN'. Structure the output with clear scene headings (e.g., SCENE 1 - INT. SPACESHIP - DAY).`;

        const response: GenerateContentResponse = await withRetry(() => defaultAi!.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `${systemPrompt}

            Here is the user's idea:
            ---
            ${idea}
            ---`,
        }));
        
        return response.text;

    } catch (error) {
        console.error("Error generating script from idea:", error);
        const errorMessage = error instanceof Error ? `Script generation failed: ${error.message}` : 'An unknown error occurred during script generation';
        throw new Error(errorMessage);
    }
}


export async function transcribeAudio(audioData: string, mimeType: string): Promise<string> {
    if (!defaultAi) {
        throw new Error("API key is not configured for audio transcription.");
    }
    try {
        const audioPart = {
            inlineData: {
                mimeType,
                data: audioData
            }
        };
        
        const textPart = {
            text: "Transcribe this audio recording into a script. If it's a story with dialogue, format it like a screenplay with character names and scene breaks. If it's a monologue or narration, provide a clean transcript."
        };

        const response: GenerateContentResponse = await withRetry(() => defaultAi!.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [audioPart, textPart] }
        }));

        return response.text;

    } catch (error) {
        console.error("Error transcribing audio:", error);
        const errorMessage = error instanceof Error ? `Transcription failed: ${error.message}` : 'An unknown error occurred during audio transcription';
        throw new Error(errorMessage);
    }
}

export async function perfectScriptForAI(script: string, tone: string): Promise<string> {
    if (!defaultAi) {
        throw new Error("API key is not configured for text generation.");
    }
    try {
        const systemPrompt = `You are a world-class voice-over director and SSML expert. Your task is to transform a plain script into a professionally annotated SSML script for an advanced AI Text-to-Speech (TTS) engine. Your goal is to make the AI's delivery sound incredibly human, natural, and perfectly aligned with the specified tone.

The desired tone for the performance is: "${tone}".

Analyze the script sentence by sentence, considering the emotional subtext and the overall narrative arc. Then, strategically embed SSML tags to guide the AI's performance.

**SSML Tag Guide:**

1.  **<break time="..." /> (Pausing):**
    *   Use short breaks (\`200ms\` to \`400ms\`) for commas, grammatical pauses, or to let a thought sink in.
    *   Use medium breaks (\`500ms\` to \`800ms\`) for sentence ends or for dramatic effect.
    *   *Example (Documentary):* "The creature moves silently <break time="400ms"/> through the undergrowth."

2.  **<emphasis level="..."> (Emphasis):**
    *   Use \`moderate\` emphasis for key words that carry the sentence's meaning.
    *   Use \`strong\` emphasis **rarely**, for a critical word or a moment of high emotion. Overusing this will sound robotic.
    *   *Example (Motivational):* "You have the power to <emphasis level="strong">change</emphasis> your future."

3.  **<prosody rate="..." pitch="..." volume="..."> (Vocal Delivery):** This is your most powerful tool for conveying tone.
    *   **rate:** Use \`slow\` or \`x-slow\` for thoughtful, serious, or somber moments. Use \`fast\` or \`x-fast\` for excitement or urgency.
    *   **pitch:** Use \`low\` or \`x-low\` for intimacy, gravity, or sadness. Use \`high\` or \`x-high\` for excitement or joy. A slight drop in pitch can signal the end of a thought.
    *   **volume:** Use \`soft\` or \`x-soft\` to simulate whispering or a confidential tone. Use \`loud\` or \`x-loud\` for shouting.
    *   *Combined Example (Excited):* "<prosody rate="fast" pitch="high">This is incredible!</prosody>"
    *   *Combined Example (Serious):* "<prosody rate="slow" pitch="low">He wasn't sure what to do next.</prosody>"

**Your High-Level Strategy:**
-   **Think like a human actor:** Where would they naturally pause? What words would they stress? How would their voice change to reflect the meaning?
-   **Vary your approach:** Create a dynamic performance. Don't apply the same tags everywhere.
-   **Subtlety is key:** A small, well-placed change is more effective than a large, obvious one.

**CRITICAL RULES:**
-   The entire output MUST be the script text with embedded SSML tags.
-   DO NOT wrap the entire output in \`<speak>\` tags.
-   DO NOT add any commentary, explanations, or notes before or after the script.
-   Ensure all SSML tags are correctly nested and closed.`;

        const response: GenerateContentResponse = await withRetry(() => defaultAi!.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `${systemPrompt}

Here is the script:
---
${script}
---`,
        }));
        
        return response.text;

    } catch (error) {
        console.error("Error perfecting script:", error);
        const errorMessage = error instanceof Error ? `Script tuning failed: ${error.message}` : 'An unknown error occurred during script tuning';
        throw new Error(errorMessage);
    }
}

export async function generateSingleScript(title: string, guides: string, outline: string, wordCount: number, apiKey: string | null = null): Promise<string> {
    const client = apiKey ? new GoogleGenAI({ apiKey }) : defaultAi;
    if (!client) {
        throw new Error("API key is not configured for text generation.");
    }
    try {
        const wordCountInstruction = wordCount > 0
            ? `**4. Word Count:** The final script should be approximately **${wordCount} words** long.`
            : `**4. Word Count:** The desired word count is not explicitly set. You MUST INFER the target length from the details and scope provided in the **Writing Guidelines** and **Script Outline**.`;

        const systemPrompt = `You are a world-class, expert scriptwriter. Your task is to write a high-quality, professional script based on the provided title, detailed guidelines, and a specific structural outline. You must adhere to all instructions precisely.

**1. Script Title:** The central theme of the script is:
<title>
${title}
</title>

**2. Writing Guidelines (MUST FOLLOW):** You must adhere strictly to these guidelines for the tone, style, voice, and content:
<guidelines>
${guides}
</guidelines>

**3. Script Outline (MUST FOLLOW):** The script must follow this exact structure. Flesh out each section thoughtfully and creatively based on the outline provided. Do not deviate from this structure.
<outline>
${outline}
</outline>

${wordCountInstruction}

**CRITICAL Final Instructions:**
- The final output must be **pure, ready-to-use prose or narrative text only**.
- **DO NOT** include any script-formatting words, tags, or labels like "NARRATOR:", "SCENE 1:", "INTRO:", "[SCENE START]", "INT./EXT.", or any other directorial notes. The text should be immediately readable by a voice-over artist without any cleanup.
- Ensure the final text flows naturally as a single, cohesive piece.
- Adhere as closely as possible to the word count requirement if one is specified.
- Do not add any of your own comments, introductions, or text outside of the requested script itself.`;
        
        const response: GenerateContentResponse = await withRetry(() => client.models.generateContent({
            model: "gemini-2.5-flash",
            contents: systemPrompt,
        }));
        
        return response.text;

    } catch (error) {
        console.error(`Error generating script for title "${title}":`, error);
        const errorMessage = error instanceof Error ? `Script generation failed: ${error.message}` : 'An unknown error occurred during script generation';
        throw new Error(errorMessage);
    }
}

export async function generateOutlineForTitle(title: string, wordCount: number, apiKey: string | null = null): Promise<{ guides: string; outline: string; }> {
    const client = apiKey ? new GoogleGenAI({ apiKey }) : defaultAi;
    if (!client) {
        throw new Error("API key is not configured for text generation.");
    }
    try {
        const systemPrompt = `You are an expert content strategist and professional script planner. Your task is to analyze a video title and a target word count, then create a professional, comprehensive plan for writing the script.

Your output MUST be a valid JSON object with two keys: "guides" and "outline".

1.  **guides**: This should be a string containing a bulleted list of essential writing guidelines. It must cover the recommended tone, style, target audience, and key points to include or avoid. The advice should be actionable and professional.

2.  **outline**: This should be a string containing a detailed, professionally structured outline for the script.
    -   Use Markdown for formatting: Use \`**double asterisks**\` to make headings and key terms bold for emphasis and clarity.
    -   The structure should be logical, typically including an Introduction (with a strong hook), a Main Body (broken into several distinct, well-defined points), and a Conclusion (with a summary and a call to action or final thought).
    -   The detail should be sufficient to guide the writing of a script of approximately ${wordCount} words.`;

        const response: GenerateContentResponse = await withRetry(() => client.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `${systemPrompt}\n\nUSER INPUT:\nTitle: "${title}"\nWord Count: ${wordCount}`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        guides: {
                            type: Type.STRING,
                            description: "A bulleted list of professional writing guidelines including tone, style, and audience.",
                        },
                        outline: {
                            type: Type.STRING,
                            description: `A detailed, professionally-formatted script outline using Markdown for a ${wordCount} word script.`,
                        },
                    },
                    required: ["guides", "outline"]
                }
            }
        }));

        const jsonText = response.text.trim();
        const result = JSON.parse(jsonText);

        if (!result || typeof result.guides !== 'string' || typeof result.outline !== 'string') {
            throw new Error("API returned an unexpected format for outline generation.");
        }

        return result;

    } catch (error) {
        console.error(`Error generating outline for title "${title}":`, error);
        const errorMessage = error instanceof Error ? `Outline generation failed: ${error.message}` : 'An unknown error occurred during outline generation';
        throw new Error(errorMessage);
    }
}
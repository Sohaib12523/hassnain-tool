
import type { Voice } from '../types';

const API_BASE_URL = 'https://api.wellsaidlabs.com/v1';

interface WellSaidSpeaker {
    speakerId: string;
    speakerName: string;
    style: 'conversational' | 'promo' | 'narration';
}

/**
 * Fetches the list of available speakers from the WellSaid Labs API.
 * @param apiKey The user's WellSaid Labs API key.
 * @returns A promise that resolves to an array of unified Voice objects.
 */
export async function fetchVoices(apiKey: string): Promise<Voice[]> {
    if (!apiKey) {
        throw new Error("WellSaid Labs API key is not provided.");
    }

    const response = await fetch(`${API_BASE_URL}/speakers`, {
        headers: {
            'X-Api-Key': apiKey,
        },
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData?.message || `Failed to fetch voices with status ${response.status}`;
        throw new Error(errorMessage);
    }

    const wellSaidSpeakers = await response.json() as WellSaidSpeaker[];

    return wellSaidSpeakers.map(speaker => ({
        id: speaker.speakerId,
        name: speaker.speakerName,
        provider: 'wellsaid',
        group: speaker.style.charAt(0).toUpperCase() + speaker.style.slice(1), // Capitalize style for display
    }));
}

/**
 * Generates audio from text using the WellSaid Labs text-to-speech API.
 * @param apiKey The user's WellSaid Labs API key.
 * @param speakerId The ID of the speaker to use for generation.
 * @param text The text to convert to speech.
 * @returns A promise that resolves to an audio Blob.
 */
export async function generateAudio(apiKey: string, speakerId: string, text: string): Promise<Blob> {
    if (!apiKey) {
        throw new Error("WellSaid Labs API key is not provided.");
    }
    if (!speakerId) {
        throw new Error("Speaker ID is not provided.");
    }
    if (!text || !text.trim()) {
        return new Blob([], { type: 'audio/mpeg' });
    }

    const response = await fetch(`${API_BASE_URL}/tts/stream/${speakerId}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'audio/mpeg',
            'X-Api-Key': apiKey,
        },
        body: JSON.stringify({
            text: text,
        }),
    });

    if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData?.message || `Failed to generate audio with status ${response.status}`;
        throw new Error(errorMessage);
    }

    return response.blob();
}

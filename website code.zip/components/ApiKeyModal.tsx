
import React, { useState, useEffect } from 'react';
import { CloseIcon, KeyIcon, PhotoIcon, MicrophoneIcon, ScriptIcon, CheckCircleIcon } from './Icons';
import type { AllApiKeys, ApiProvider, VoiceProvider, BulkScriptApiProvider } from '../types';

interface ApiKeyModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentKeys: AllApiKeys;
  onSave: (keys: AllApiKeys) => void;
  onClear: () => void;
  onSaveSingleKey: (section: keyof AllApiKeys, provider: string, key: string) => void;
}

const IMAGE_PROVIDERS: { id: ApiProvider; name: string; }[] = [
    { id: 'gemini', name: 'Gemini (Image & More)' },
    { id: 'together', name: 'TogetherAI (Image)' },
    { id: 'leonardo', name: 'Leonardo.Ai (Image)' },
    { id: 'ideogram', name: 'Ideogram (Image)' },
    { id: 'runway', name: 'RunwayML (Image)' },
];

const VOICE_PROVIDERS: { id: VoiceProvider; name: string; }[] = [
    { id: 'elevenlabs', name: 'ElevenLabs (Voice & SFX)' },
    { id: 'wellsaid', name: 'WellSaid Labs (Voice)' },
];

const SCRIPT_PROVIDERS: { id: Exclude<BulkScriptApiProvider, 'gemini'>; name: string; }[] = [
    { id: 'openai', name: 'OpenAI (GPT)' },
    { id: 'groq', name: 'Grok AI' },
    { id: 'deepseek', name: 'DeepSeek' },
];

const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ 
    isOpen, 
    onClose, 
    currentKeys,
    onSave, 
    onClear,
    onSaveSingleKey,
}) => {
  const [localKeys, setLocalKeys] = useState<AllApiKeys>(currentKeys);
  const [savedStatus, setSavedStatus] = useState<Record<string, boolean>>({});

  useEffect(() => {
    setLocalKeys(currentKeys);
  }, [currentKeys, isOpen]);
  
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleKeyChange = <T extends keyof AllApiKeys>(
    section: T, 
    provider: keyof AllApiKeys[T], 
    value: string
  ) => {
    setLocalKeys(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [provider]: value, // Store with leading/trailing spaces for user convenience
      },
    }));
  };

  const handleIndividualSave = (section: keyof AllApiKeys, provider: string) => {
    const key = ((localKeys[section] as any)[provider] || '').trim();
    onSaveSingleKey(section, provider, key);
    
    const statusKey = `${section}-${provider}`;
    setSavedStatus(prev => ({ ...prev, [statusKey]: true }));
    setTimeout(() => {
        setSavedStatus(prev => ({ ...prev, [statusKey]: false }));
    }, 2000);
  };

  const handleSaveClick = () => {
    const keysToSave = JSON.parse(JSON.stringify(localKeys));
    if (keysToSave.image && 'gemini' in keysToSave.image) {
      delete keysToSave.image.gemini;
    }

    // Trim all keys before saving all
    for (const section in keysToSave) {
        for (const provider in keysToSave[section as keyof AllApiKeys]) {
            keysToSave[section as keyof AllApiKeys][provider as keyof AllApiKeys[keyof AllApiKeys]] = (keysToSave[section as keyof AllApiKeys][provider as keyof AllApiKeys[keyof AllApiKeys]] || '').trim();
        }
    }

    onSave(keysToSave);
    onClose();
  };
  
  const handleClearClick = () => {
    onClear();
    onClose();
  };

  const hasAnyCustomKey = 
    (localKeys.image && Object.entries(localKeys.image).some(([provider, key]) => provider !== 'gemini' && !!key)) ||
    (localKeys.voice && Object.values(localKeys.voice).some(key => !!key)) ||
    (localKeys.script && Object.values(localKeys.script).some(key => !!key));


  const renderSection = (title: string, icon: JSX.Element, inputs: JSX.Element[]) => (
      <div>
        <h3 className="text-base font-semibold text-gray-700 dark:text-white mb-3 flex items-center gap-2 border-b border-slate-200 dark:border-[#252f41] pb-2">
            {icon}
            {title}
        </h3>
        <div className="space-y-4">
            {inputs}
        </div>
      </div>
  );
  
  const renderInputWithSave = (section: keyof AllApiKeys, provider: string, name: string) => {
    const statusKey = `${section}-${provider}`;
    const isSaved = savedStatus[statusKey];

    return (
        <div key={provider}>
            <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1.5">{name}</label>
            <div className="flex items-center gap-2">
                <input
                    type="password"
                    value={(localKeys[section] as any)[provider] || ''}
                    onChange={(e) => handleKeyChange(section as any, provider, e.target.value)}
                    className="flex-grow w-full bg-white dark:bg-[#0b1120] border border-slate-200 dark:border-[#252f41] rounded-lg p-2.5 text-base focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 outline-none"
                    placeholder={`Paste ${name} key here`}
                />
                <button
                    onClick={() => handleIndividualSave(section, provider)}
                    disabled={isSaved}
                    className={`flex-shrink-0 flex items-center justify-center gap-1.5 w-24 px-3 py-2.5 rounded-lg font-semibold transition-colors ${
                        isSaved
                        ? 'bg-green-100 dark:bg-green-900/40 text-green-600 dark:text-green-300 cursor-default'
                        : 'bg-slate-200 dark:bg-[#252f41] text-gray-800 dark:text-white hover:bg-slate-300 dark:hover:bg-cyan-500/10'
                    }`}
                >
                    {isSaved ? (
                        <><CheckCircleIcon className="h-5 w-5" /> Saved</>
                    ) : (
                        'Save'
                    )}
                </button>
            </div>
        </div>
    );
  };


  return (
    <div
      className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 transition-opacity duration-300 animate-fade-in backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="api-key-modal-title"
    >
      <div
        className="bg-slate-50 dark:bg-[#172134] rounded-2xl shadow-2xl w-full max-w-lg flex flex-col relative border border-slate-200 dark:border-[#252f41] max-h-[90vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 border-b border-slate-200 dark:border-[#252f41]">
            <div className="flex justify-between items-start">
                 <div>
                    <h2 id="api-key-modal-title" className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                        <KeyIcon className="h-6 w-6 text-cyan-500 dark:text-cyan-400" />
                        Custom API Keys
                    </h2>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">Provide your own API keys to bypass daily limits.</p>
                </div>
                <button
                    onClick={onClose}
                    className="p-1.5 bg-slate-200 dark:bg-[#0b1120] rounded-full hover:bg-slate-300 dark:hover:bg-cyan-500/10 transition-colors"
                    aria-label="Close"
                >
                    <CloseIcon className="h-5 w-5 text-gray-800 dark:text-white" />
                </button>
            </div>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto">
             {renderSection(
                'Image Generation',
                <PhotoIcon className="h-5 w-5" />,
                IMAGE_PROVIDERS.map(p => {
                    if (p.id === 'gemini') {
                        return (
                            <div key={p.id}>
                                <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1.5">{p.name}</label>
                                <div className="w-full bg-slate-100 dark:bg-[#0b1120] border border-slate-200 dark:border-[#252f41] rounded-lg p-2.5 text-base text-gray-500 dark:text-gray-400">
                                    Default
                                </div>
                            </div>
                        )
                    }
                    return renderInputWithSave('image', p.id, p.name);
                })
            )}
            {renderSection(
                'Voice Generation',
                <MicrophoneIcon className="h-5 w-5" />,
                VOICE_PROVIDERS.map(p => renderInputWithSave('voice', p.id, p.name))
            )}
            {renderSection(
                'Script Generation',
                <ScriptIcon className="h-5 w-5" />,
                SCRIPT_PROVIDERS.map(p => renderInputWithSave('script', p.id, p.name))
            )}
             <p className="text-xs text-center text-gray-500 dark:text-gray-400 pt-2">Your keys are saved securely in your browser's local storage.</p>
        </div>
        
        <div className="p-6 mt-auto border-t border-slate-200 dark:border-[#252f41] bg-slate-50 dark:bg-[#172134]/80">
            <div className="space-y-3">
                <button
                    onClick={handleSaveClick}
                    className="w-full gradient-button text-white font-bold py-2.5 px-4 rounded-lg transition-all"
                >
                    Save All Keys
                </button>
                 <button
                    onClick={handleClearClick}
                    disabled={!hasAnyCustomKey}
                    className="w-full bg-slate-200 dark:bg-[#0b1120] hover:bg-slate-300 dark:hover:bg-cyan-500/10 text-gray-800 dark:text-gray-300 font-bold py-2.5 px-4 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                    Clear All Custom Keys
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ApiKeyModal;

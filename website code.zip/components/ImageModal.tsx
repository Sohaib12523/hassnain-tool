


import React, { useEffect, useState } from 'react';
import type { ImageJob, AspectRatio, ApiProvider } from '../types';
import { CloseIcon, SparkleIcon } from './Icons';
import { generateSingleImage as generateGeminiImage } from '../services/geminiService';
import { generateSingleImage as generateTogetherImage } from '../services/aiService';
// Mock imports for other services will go here if they have unique single-image functions
import * as leonardoService from '../services/leonardoService';
import * as ideogramService from '../services/ideogramService';
import * as runwayService from '../services/runwayService';


interface EditModalProps {
  job: ImageJob;
  apiProvider: ApiProvider;
  imageStyles: string[];
  aspectRatio: AspectRatio;
  steps?: number;
  apiKey: string | null;
  onClose: () => void;
  onSave: (jobId: string, newPrompt: string, newImageUrl: string) => void;
  onSpendCredit: (amount: number) => boolean;
}

const EditModal: React.FC<EditModalProps> = ({ job, apiProvider, imageStyles, aspectRatio, steps, apiKey, onClose, onSave, onSpendCredit }) => {
  const [currentPrompt, setCurrentPrompt] = useState(job.prompt);
  const [currentImageUrl, setImageUrl] = useState(job.imageUrl);
  const [currentStyle, setCurrentStyle] = useState('None');
  const [enhanceQuality, setEnhanceQuality] = useState(false);
  
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const hasBeenEdited = currentImageUrl !== job.imageUrl;

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);
  
  const handleRegenerate = async () => {
    if (apiProvider === 'gemini' && !apiKey) {
      if (!onSpendCredit(1)) {
          setError("Not enough credits to regenerate. Credits reset daily.");
          return;
      }
    }


    setIsRegenerating(true);
    setError(null);
    
    let finalPrompt = currentPrompt;
    if (enhanceQuality) {
        finalPrompt += ", 4k, high resolution, ultra detailed, sharp focus";
    }
    if (currentStyle !== 'None') {
        finalPrompt += `, in a ${currentStyle.toLowerCase()} style`;
    }

    try {
        let result;
        // This logic needs to be expanded for new providers if they have a single image function
        switch(apiProvider) {
          case 'gemini':
            result = await generateGeminiImage(finalPrompt, aspectRatio, apiKey);
            break;
          case 'together':
            result = await generateTogetherImage(finalPrompt, aspectRatio, steps || 10, apiKey);
            break;
          case 'leonardo':
          case 'ideogram':
          case 'runway':
             // Since these are mock services, we simulate their behavior
             setError(`${apiProvider.charAt(0).toUpperCase() + apiProvider.slice(1)} integration is not yet fully implemented.`);
             setIsRegenerating(false);
             return;
          default:
            throw new Error(`Unsupported provider: ${apiProvider}`);
        }
            
        if (result.url) {
            setImageUrl(result.url);
        } else {
            setError(result.error || 'Generation failed for an unknown reason.');
        }
    } catch (err) {
        setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
        setIsRegenerating(false);
    }
  };

  const handleSave = () => {
    if (currentImageUrl) {
        onSave(job.id, currentPrompt, currentImageUrl);
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 transition-opacity duration-300 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="edit-modal-title"
    >
      <div
        className="bg-slate-50 dark:bg-[#172134] rounded-2xl shadow-2xl w-full max-w-5xl h-full max-h-[90vh] flex flex-col md:flex-row relative overflow-hidden border border-slate-200 dark:border-[#252f41]"
        onClick={(e) => e.stopPropagation()}
      >
        <button
            onClick={onClose}
            className="absolute top-3 right-3 p-2 bg-black/30 rounded-full hover:bg-black/50 transition-colors z-10"
            aria-label="Close"
        >
            <CloseIcon className="text-white"/>
        </button>

        <div className="w-full md:w-1/2 lg:w-3/5 bg-slate-200 dark:bg-black/30 flex items-center justify-center p-4 relative h-1/2 md:h-full">
            {isRegenerating && (
                 <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center gap-2 text-slate-300 z-10">
                    <div role="status" className="h-10 w-10 animate-spin rounded-full border-4 border-solid border-cyan-500 border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]" />
                    <span>Regenerating...</span>
                </div>
            )}
            {error && !isRegenerating && (
                 <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center gap-2 text-red-400 p-4 z-10">
                    <p className="font-bold text-lg">Generation Failed</p>
                    <p className="text-sm text-center">{error}</p>
                </div>
            )}
            {currentImageUrl && <img src={currentImageUrl} alt={currentPrompt} className="w-auto h-auto max-w-full max-h-full object-contain rounded-lg"/>}
        </div>

        <div className="w-full md:w-1/2 lg:w-2/5 p-6 flex flex-col space-y-4 overflow-y-auto h-1/2 md:h-full">
          <h2 id="edit-modal-title" className="text-2xl font-bold text-gray-900 dark:text-white">Edit & Enhance</h2>
          
          <div>
            <label htmlFor="edit-prompt" className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-1">Prompt</label>
            <textarea
                id="edit-prompt"
                value={currentPrompt}
                onChange={(e) => setCurrentPrompt(e.target.value)}
                rows={5}
                className="w-full bg-white dark:bg-[#0b1120] border border-slate-200 dark:border-[#252f41] rounded-xl p-3 text-base focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 outline-none transition-all duration-300 resize-y"
                disabled={isRegenerating}
            />
          </div>
          
           <div>
              <label className="block text-sm font-medium text-gray-600 dark:text-gray-300 mb-2">Image Style</label>
              <select
                value={currentStyle}
                onChange={(e) => setCurrentStyle(e.target.value)}
                disabled={isRegenerating || imageStyles.length === 0}
                className="w-full bg-white dark:bg-[#0b1120] border border-slate-200 dark:border-[#252f41] rounded-lg p-2.5 text-base focus:ring-2 focus:ring-cyan-500/50 focus:border-cyan-500 outline-none transition-all duration-300"
              >
                  {imageStyles.map(style => (
                    <option key={style} value={style}>{style}</option>
                  ))}
              </select>
          </div>
          
           <div
                role="switch"
                aria-checked={enhanceQuality}
                onClick={() => !isRegenerating && setEnhanceQuality(!enhanceQuality)}
                className={`flex items-center justify-between p-3 rounded-lg transition-colors cursor-pointer ${enhanceQuality ? 'bg-cyan-600/20' : 'bg-slate-200 dark:bg-[#0b1120]'}`}
            >
                <div className="flex items-center gap-3">
                    <SparkleIcon className="text-cyan-500 dark:text-cyan-400"/>
                    <span className="font-semibold text-gray-800 dark:text-white">Enhance Quality (4K)</span>
                </div>
                <div className={`w-11 h-6 rounded-full flex items-center p-1 transition-colors ${enhanceQuality ? 'bg-cyan-500' : 'bg-gray-400 dark:bg-gray-700'}`}>
                    <div className={`w-4 h-4 bg-white rounded-full transition-transform ${enhanceQuality ? 'transform translate-x-5' : ''}`}/>
                </div>
            </div>
            
            <div className="flex-grow"></div>

            <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-[#252f41]">
                 <button
                    type="button"
                    onClick={handleRegenerate}
                    disabled={isRegenerating || !currentPrompt.trim()}
                    className="w-full flex items-center justify-center gap-2 bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-3 px-5 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                    {isRegenerating ? (
                        <>
                           <div role="status" className="inline-block h-5 w-5 animate-spin rounded-full border-2 border-solid border-current border-r-transparent motion-reduce:animate-[spin_1.5s_linear_infinite]" />
                            Regenerating...
                        </>
                    ) : "Regenerate Image"}
                </button>
                <button
                    type="button"
                    onClick={handleSave}
                    disabled={isRegenerating || !hasBeenEdited}
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-5 rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                    Save & Close
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default EditModal;
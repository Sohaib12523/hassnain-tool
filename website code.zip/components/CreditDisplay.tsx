


import React, { useState, useEffect } from 'react';
import { CreditIcon } from './Icons';
import type { ApiProvider } from '../types';

interface CreditDisplayProps {
  credits: number;
  nextReset: Date | null;
  isCustomKey: boolean;
  apiProvider: ApiProvider;
}

const formatTimeLeft = (ms: number) => {
    if (ms <= 0) return '00:00:00';
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
};

const CreditDisplay: React.FC<CreditDisplayProps> = ({ credits, nextReset, isCustomKey, apiProvider }) => {
    const [timeLeft, setTimeLeft] = useState<number | null>(null);

    useEffect(() => {
        if (!nextReset || credits > 0) {
            setTimeLeft(null);
            return;
        }

        const calculateTimeLeft = () => {
            const now = new Date().getTime();
            const resetTime = nextReset.getTime();
            const newTimeLeft = Math.max(0, resetTime - now);
            setTimeLeft(newTimeLeft);

            // If timer reaches zero, we can stop the interval. 
            // A page refresh will handle the credit reset.
            if (newTimeLeft <= 0) {
                 clearInterval(interval);
            }
        };

        const interval = setInterval(calculateTimeLeft, 1000);
        calculateTimeLeft(); // Initial call

        return () => clearInterval(interval);
    }, [nextReset, credits]);

    // This component is only for the default Gemini provider without a custom key
    if (isCustomKey || apiProvider !== 'gemini') {
        return null;
    }

    return (
        <div className="flex items-center gap-2 p-1.5 pr-3 bg-slate-200/80 dark:bg-[#172134] rounded-full border border-slate-300 dark:border-[#252f41] backdrop-blur-sm transition-all animate-fade-in">
            <div className="flex items-center justify-center bg-cyan-100 dark:bg-cyan-900/50 h-6 w-6 rounded-full">
                <CreditIcon className="h-4 w-4 text-cyan-600 dark:text-cyan-300" />
            </div>
            <div className="text-sm font-semibold text-gray-700 dark:text-gray-200">
                {credits > 0 ? (
                    <span className="whitespace-nowrap">{credits} Credits Left</span>
                ) : (
                    <div className="flex items-center gap-1.5">
                       <span className="whitespace-nowrap">Next credits in:</span>
                       <span className="font-mono bg-black/10 dark:bg-white/10 px-1.5 py-0.5 rounded">{timeLeft !== null ? formatTimeLeft(timeLeft) : '...'}</span>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CreditDisplay;
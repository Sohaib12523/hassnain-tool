


import React, { useState, useRef, useEffect, useMemo } from 'react';
import type { Voice, PreviewState, VoiceProvider } from '../types';
import { PlayIcon, StopIcon } from './Icons';

interface VoiceSelectorProps {
    voices: Voice[];
    selectedValue: string;
    onSelect: (value: string) => void;
    onPreview: (voiceId: string, provider: VoiceProvider) => void;
    previewStatus: { id: string | null; state: PreviewState };
    isFetching: boolean;
    isUsingApiKey: boolean;
    apiKeyProviderName: string; // e.g., "ElevenLabs" or "WellSaid Labs"
    onOpenApiKeyModal: () => void;
    uiVariant?: 'light' | 'dark';
}

const VoiceSelector: React.FC<VoiceSelectorProps> = ({
    voices,
    selectedValue,
    onSelect,
    onPreview,
    previewStatus,
    isFetching,
    isUsingApiKey,
    apiKeyProviderName,
    onOpenApiKeyModal,
    uiVariant = 'light'
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);

    const isDark = uiVariant === 'dark';

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
                setIsOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);

    const handleSelect = (value: string) => {
        onSelect(value);
        setIsOpen(false);
    };

    const getSelectedVoiceName = () => {
        if (!selectedValue) return isDark ? 'Select Voice' : 'No Voiceover';
        const voice = voices.find(v => v.id === selectedValue);
        if (voice) return voice.name;
        return isDark ? 'Select Voice' : 'No Voiceover';
    };
    
    const groupedVoices = useMemo(() => {
        if (!voices) return {};
        return voices.reduce((acc, voice) => {
            const groupName = voice.group || 'General';
            if (!acc[groupName]) {
                acc[groupName] = [];
            }
            acc[groupName].push(voice);
            return acc;
        }, {} as Record<string, Voice[]>);
    }, [voices]);


    const renderPreviewButton = (voice: Voice) => {
        const status = previewStatus.id === voice.id ? previewStatus.state : 'idle';

        const handlePreviewClick = (e: React.MouseEvent) => {
            e.stopPropagation();
            onPreview(voice.id, voice.provider);
        };

        const hoverClasses = isDark ? 'hover:bg-cyan-500/10' : 'hover:bg-slate-200';
        const textClasses = isDark ? 'text-gray-400' : 'text-gray-500';
        const activeColor = 'text-cyan-500';

        return (
            <button
                onClick={handlePreviewClick}
                disabled={status === 'loading'}
                className={`p-2 rounded-full ${hoverClasses} ${textClasses} disabled:cursor-wait disabled:text-gray-400 transition-colors`}
                aria-label={`Preview voice ${voice.name}`}
            >
                {status === 'loading' && <div role="status" className={`w-4 h-4 animate-spin rounded-full border-2 border-solid border-cyan-500 border-r-transparent`} />}
                {status === 'playing' && <StopIcon className={`w-4 h-4 ${activeColor}`} />}
                {status === 'idle' && <PlayIcon className="w-4 h-4" />}
            </button>
        );
    };
    
    const baseButtonClasses = "w-full rounded-md p-2.5 text-base focus:ring-2 outline-none flex justify-between items-center text-left";
    const lightButtonClasses = "bg-white dark:bg-[#0b1120] border border-slate-200 dark:border-[#252f41] focus:ring-cyan-500 rounded-lg";
    const darkButtonClasses = "bg-[#0b1120] border border-[#252f41] text-gray-300 focus:ring-cyan-500";
    const buttonClasses = `${baseButtonClasses} ${isDark ? darkButtonClasses : lightButtonClasses}`;
    
    const listBaseClasses = "absolute z-10 w-full mt-2 border rounded-lg shadow-xl max-h-60 overflow-y-auto";
    const lightListClasses = "bg-white border-slate-200";
    const darkListClasses = "bg-[#172134] border-[#252f41]";
    const listClasses = `${listBaseClasses} ${isDark ? darkListClasses : lightListClasses}`;
    
    const itemBaseClasses = "px-4 py-2 text-sm cursor-pointer";
    const lightItemClasses = "text-gray-700 hover:bg-slate-100";
    const darkItemClasses = "text-gray-300 hover:bg-cyan-500/10";
    const itemClasses = `${itemBaseClasses} ${isDark ? darkItemClasses : lightItemClasses}`;
    
    const groupItemClasses = `px-4 pt-2 pb-1 text-xs font-bold uppercase ${isDark ? 'text-gray-500' : 'text-gray-500'}`;

    return (
        <div className="relative w-full" ref={wrapperRef}>
            <button onClick={() => setIsOpen(!isOpen)} className={buttonClasses}>
                <span className="truncate">{getSelectedVoiceName()}</span>
                <svg className={`w-5 h-5 ml-2 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
            </button>

            {isOpen && (
                <div className={listClasses}>
                    <ul className="py-1">
                        {!isDark && (
                            <li onClick={() => handleSelect('')} className={itemClasses}>
                                No Voiceover
                            </li>
                        )}
                        
                        {isFetching && <li className={itemClasses}>Loading voices...</li>}

                        {!isFetching && isUsingApiKey && voices.length > 0 && (
                             <>
                                {Object.entries(groupedVoices).map(([groupName, voiceList]) => (
                                    <React.Fragment key={groupName}>
                                        <li className={groupItemClasses}>{groupName}</li>
                                        {voiceList.map(v => (
                                            <li key={v.id} onClick={() => handleSelect(v.id)} className={`${itemClasses} flex justify-between items-center group`}>
                                                <span className="truncate pr-2">{v.name}</span>
                                                {renderPreviewButton(v)}
                                            </li>
                                        ))}
                                    </React.Fragment>
                                ))}
                            </>
                        )}
                        
                        {!isFetching && (!isUsingApiKey || voices.length === 0) && (
                            <li className={`${itemClasses} text-xs`}>
                                Please enter a valid <span className="font-bold">{apiKeyProviderName}</span> API key to load voices.
                            </li>
                        )}
                    </ul>
                </div>
            )}
        </div>
    );
};

export default VoiceSelector;